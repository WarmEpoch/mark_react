# Installation
> `npm install --save @types/html5plus`

# Summary
This package contains type definitions for html5plus (https://www.html5plus.org/doc/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/html5plus.

### Additional Details
 * Last updated: Thu, 08 Jul 2021 14:22:55 GMT
 * Dependencies: none
 * Global values: `plus`

# Credits
These definitions were written by [Dcloud](https://github.com/dcloudio).
